import React from "react";
import "./styles.css"; // make sure CSS is imported

export default function App() {
  return (
    <div className="main-wrapper">
      <div className="background">
        <div className="login-container">
          <h1>Sign In</h1>
          <input type="text" placeholder="Email or mobile number" />
          <input type="password" placeholder="Password" />
          <button>Sign In</button>
        </div>
      </div>

      <footer className="footer">
        <p>Questions? Contact us.</p>
        <ul className="footer-links">
          <li>
            <a href="#">FAQ</a>
          </li>
          <li>
            <a href="#">Help Center</a>
          </li>
          <li>
            <a href="#">Terms of Use</a>
          </li>
          <li>
            <a href="#">Privacy</a>
          </li>
          <li>
            <a href="#"></a>Cookie Preferences
          </li>
          <li>
            <a href="#">Corporate Information</a>
          </li>
        </ul>
      </footer>
    </div>
  );
}
